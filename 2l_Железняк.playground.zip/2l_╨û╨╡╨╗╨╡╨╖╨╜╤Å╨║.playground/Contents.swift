import UIKit



// Задание №1.
func CountNumber2 (_ num2: Int) -> Bool {
    return num2 % 2 == 0
}
let count2 = CountNumber2(8)
print(count2)



// Задание №2.
func CountNumber3 (_ num3: Int) -> Bool {
    return num3 % 3 == 0
}
let count3 = CountNumber3(9)
print(count3)



// Задание №3.
func IncreaseArray() -> Array<Int> {
    var a: Array<Int> = []
    var array = 0
    var i: Int = 0
    for i in 0..<100 {
        array += 1
        a.append(array)
    }
    return a
}

var arr = IncreaseArray()
print(arr)



// Задание №4.
func Array() -> Array<Int> {
    return arr.filter ({$0 % 3 == 0 && $0 % 2 != 0})
}
var massive = Array()
print(massive)



// Задание №5.
func FibonachiArray() -> Array<Double> {
    var fib: Array<Double> = [0, 1]
    var i: Int = 0
    for i in 0..<98 {
        fib.append(fib[fib.count - 1] + fib[fib.count - 2])
    }
    return fib
}
var fibArray = FibonachiArray()
print(fibArray)
